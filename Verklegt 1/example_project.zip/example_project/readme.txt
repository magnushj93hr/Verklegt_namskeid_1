Uppsetning
Layer tengingar
Class instances
Debugging
Back button og stackurinn