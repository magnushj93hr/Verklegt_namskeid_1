from ui_layer.MainMenu import MainMenu

if __name__ == "__main__":
    main_menu = MainMenu()
    main_menu.draw_options()